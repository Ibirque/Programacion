He intentado hacer todo lo que he podido sin ayuda de IA, 
pero al final he tenido que recurrir a una de ellas

En la funcion de la linea 190 "FuncionDeEncriptacion" codificaba palabras si no eran demasiado largas

Por ejemplo si mandaba la palabra "Esternocleidomastoideo" y el cifrado "Flandria" funcionaba
Sin embargo, si mandaba las palabras "Albondigas de caballo" con el mismo cifrado, el programa estallaba, 
y no era por los espacios ya que incluso escribiendo "esterno cleidomastoideo" funcionaba

Las seccion conformada entre las lineas 210 y 232 esta escrita por el chat, aun asi te he
dejado justo arriba el codigo para que lo veas, 
puedes descomentarlo si quieres (recuerda comentar la seccion de chatGPT) y podras ver que funcionaba a medias

La ia tambien me recomendo añadir las lineas 247 a 249 para lidiar con los espacios.



Por lo demas he hecho lo que podido, no se por que el descifrado con la clave privada no funciona, 
pero tengo la cabeza como un bombo y me niego a usar la IA para terminarlo.


Quizas en el futuro lo haga en JavaFX que tiene una interfaz mas aceptable, peor no me acuerdo
de lo que hicimos el año pasado.